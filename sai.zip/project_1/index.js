
const ele = document.getElementsByClassName('clg')

for(var i = 0; i < ele.length; i++)
            {
                ele[i].onclick = function(){
                    
                    // remove class from sibling
                    
                    var el = ele[0];
                    while(el)
                    {
                        if(el.tagName === "TD"){
                            //remove class
                            el.classList.remove("active");
                            
                        }
                        // pass to the new sibling
                        el = el.nextSibling;
                    }
                    
                  this.classList.add("active");  
                };
            }








